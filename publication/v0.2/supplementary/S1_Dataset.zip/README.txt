S1 Dataset. Numerical tables, eligibility criteria and influence diagnostics. CSV headers specify units; see S1 Text for definitions. Referenced in manuscript Supporting information captions.
